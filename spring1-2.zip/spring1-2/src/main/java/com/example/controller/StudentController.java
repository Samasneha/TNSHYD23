package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Student;
import com.example.service.StudentService;

@RestController
public class StudentController {
@Autowired
StudentService service;
@PostMapping("/student")
public Student saveStudent(@RequestBody Student student) {
	
	return service.saveStudent(student);
	
} 
@GetMapping("/student")
public List<Student> fetchPlacementList() {
    //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
    return service.fetchPlacemList();
} 
@GetMapping("/student/{id}")
public Student fetchPlacementById(@PathVariable("id") Long id)
{
return service.fetchPlacementById(id);
}	 

@DeleteMapping("/student/{id}")
  public String deletePlacementById(@PathVariable("id") Long id) {
	  service.deletePlacementById(id);
      return "Placement deleted Successfully!!";
}
}