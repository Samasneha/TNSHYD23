package com.example.service;

import java.util.List;

import com.example.entity.Student;

public interface StudentService {
	Student saveStudent(Student student);

	List<Student> fetchPlacemList();

	Student fetchPlacementById(Long id);

	void deletePlacementById(Long id);

}
