package com.example.demo.services;


	import java.util.List;

import com.example.demo.entity.Student;

	public interface StudentService {
		Student saveStudent(Student student);

		List<Student> fetchPlacemList();

		Student fetchPlacementById(Long id);

		void deletePlacementById(Long id);

	}


